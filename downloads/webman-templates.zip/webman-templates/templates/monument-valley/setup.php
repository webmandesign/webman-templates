<?php if ( ! defined( 'WPINC' ) ) exit;

/**
 * Theme template files setup
 *
 * @since    1.0
 * @version  1.0
 */
$theme_template_files = array(
		'rows-content.dat',
		'rows-intro.dat',
		'rows-shop.dat',
	);
