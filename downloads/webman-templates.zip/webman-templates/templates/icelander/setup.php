<?php if ( ! defined( 'WPINC' ) ) exit;

/**
 * Theme template files setup
 *
 * @since    2.0.0
 * @version  2.0.0
 */
$theme_template_files = array(
		'rows-content.dat',
		'rows-intro.dat',
		'rows-shop.dat',
	);
